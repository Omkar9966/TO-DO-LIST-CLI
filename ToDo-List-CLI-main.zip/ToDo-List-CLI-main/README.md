# To-Do List CLI ✅📝

A simple command-line to-do list manager.

## Features
- ✍️ Add and remove tasks
- 📜 View all tasks

## How to Use
1. Run `python todo_list.py`
2. Manage tasks via the command line

## License
MIT License
